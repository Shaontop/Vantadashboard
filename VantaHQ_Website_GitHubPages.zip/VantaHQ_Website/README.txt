VantaHQ Dashboard — Free Static Website

PUBLISH WITH GITHUB PAGES
1. Sign in or create a free account at https://github.com
2. Click + (top-right) > New repository.
3. Name it vantahq-dashboard. Set it to Public. Click Create repository.
4. Click Add file > Upload files.
5. Upload index.html from this folder. Click Commit changes.
6. Open the repository's Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Choose branch main and folder /(root), then click Save.
9. Wait a few minutes. GitHub will show your website URL in Settings > Pages.

IMPORTANT LIMITATIONS
- This publishes the dashboard as a static website only.
- Settings are stored in each visitor's browser; they do not update your Discord bot.
- Do not put your Discord bot token, client secret, or other secrets in index.html or any public repository.
- A live bot dashboard requires a secure backend/API and Discord OAuth permission checks.
